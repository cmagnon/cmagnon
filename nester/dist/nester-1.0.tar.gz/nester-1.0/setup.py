from distutils.core import setup

setup (
    name='nester',
    version='1.0',
    py_modules=['nester'],
    author='cmagnon',
    description = 'Printer of Nested Lists',
)
