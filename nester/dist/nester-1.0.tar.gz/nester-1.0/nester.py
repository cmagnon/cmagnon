'''Collection of tools for deepsearching lists within lists'''
def print_lol(the_list):
    '''print all elements in a list nesting other lists'''
    for item in the_list:
        if isinstance(item, list):
            print_lol(item)
        else:
            print(item)